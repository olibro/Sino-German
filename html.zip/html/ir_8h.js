var ir_8h =
[
    [ "IRL", "ir_8h.html#a2b0b1ce1c13ea829779377f8960fbb75", null ],
    [ "IRR", "ir_8h.html#af99504936a6d2e3f02d1d4cf67cf0989", null ],
    [ "init_irsens", "ir_8h.html#a9b70648f9e1b44f1c8460b509c1ddd38", null ]
];